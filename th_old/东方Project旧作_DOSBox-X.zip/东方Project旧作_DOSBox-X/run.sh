flatpak run com.dosbox_x.DOSBox-X
